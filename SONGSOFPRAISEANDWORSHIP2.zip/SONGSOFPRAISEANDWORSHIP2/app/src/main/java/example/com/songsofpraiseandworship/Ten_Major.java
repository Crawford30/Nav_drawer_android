package example.com.songsofpraiseandworship;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.view.View;
import android.content.Intent;



public class Ten_Major  extends MainActivity {
    String items[]={ "1. NEAR THE CROSS","2. THE GREAT PHYSICIAN", "3. HOW GREAT THOU ART","4. WHAT A FRIEND WE HAVE IN JESUS", "5. THE UNSEEN HAND","6. THE OLD COUNTRY CHURCH","7. THE LILY OF THE VALLEY","8. MUST JESUS BEAR THE CROSS ALONE","9. THE ROYAL TELEPHONE","10. HOLD TO GOD’S UNCHANGING HAND"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ten_major_activity);

       // public void onClickView(View v){
         //   ListView listView;
            //listView = (ListView)findViewById(R.id.TEN);

        ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
        ListView listView = new ListView(this);
        listView.setAdapter(itemsAdapter);




    }
}