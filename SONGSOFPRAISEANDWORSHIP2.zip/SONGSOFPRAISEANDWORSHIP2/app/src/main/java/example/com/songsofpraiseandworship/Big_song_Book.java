package example.com.songsofpraiseandworship;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Big_song_Book  extends MainActivity{

    String BigSongList[] = {"FILL ME WITH THY HOLY SPIRIT", "WHAT A FRIEND WE HAVE IN JESUS", "UNTIL THEN", "TAKE MY HANDS", "TURN YOUR RADIO ON", "IF GOD BE FOR US"};
    ListView simpleList;

    @Override   protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.big_song_activity);
        simpleList = (ListView)findViewById(R.id.big_song_book_index);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.big_song_activity, R.id.textView, BigSongList);
        simpleList.setAdapter(arrayAdapter);
        //simpleList = (ListView)findViewById(R.id.simpleListView);
        //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview, R.id.textView, countryList);
        //simpleList.setAdapter(arrayAdapter);
    }
}
